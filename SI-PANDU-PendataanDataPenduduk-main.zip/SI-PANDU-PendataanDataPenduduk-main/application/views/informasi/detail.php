<div class="container mt-5">
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"> <?= $detail->judul; ?> </h5>

                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">&rarr; <?= $detail->detail; ?> </li>
                    <li class="list-group-item">&rarr; <?= $detail->tgl_upload; ?> </li>
                </ul>

            </div>
        </div>
    </div>
</div>